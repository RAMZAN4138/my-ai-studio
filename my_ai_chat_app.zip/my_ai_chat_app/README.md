# My AI Chat

Simple ChatGPT-style starter app using an OpenAI API on the server.

## Run
1. Install Node.js.
2. Copy `.env.example` to `.env`.
3. Put your own OpenAI API key in `.env`.
4. Run `npm install`.
5. Run `npm start`.
6. Open http://localhost:3000

Never put the API key in browser JavaScript or publish it.
