const chat=document.getElementById('chat'),form=document.getElementById('form'),input=document.getElementById('message');
function add(text,cls){const d=document.createElement('div');d.className='msg '+cls;d.textContent=text;chat.appendChild(d);chat.scrollTop=chat.scrollHeight;return d}
form.addEventListener('submit',async e=>{e.preventDefault();const text=input.value.trim();if(!text)return;input.value='';add(text,'user');const thinking=add('Thinking...','ai');try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text})});const data=await r.json();thinking.textContent=data.reply||data.error||'No response';}catch{thinking.textContent='Connection error.'}});
document.getElementById('clear').onclick=()=>chat.innerHTML='';
