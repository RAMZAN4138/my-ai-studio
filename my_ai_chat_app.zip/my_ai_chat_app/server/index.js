require("dotenv").config();
const express = require("express");
const OpenAI = require("openai");
const app = express();
app.use(express.json());
app.use(express.static("public"));
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message required" });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      input: message,
      store: false
    });
    res.json({ reply: response.output_text || "No response" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "AI request failed. Check your API key and model access." });
  }
});
app.listen(process.env.PORT || 3000, () => console.log(`Running on http://localhost:${process.env.PORT || 3000}`));
